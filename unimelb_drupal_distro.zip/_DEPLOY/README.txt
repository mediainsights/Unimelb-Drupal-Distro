Media Insights - Unimelb Drupal Distro

thanks to Aaron Tan and team at the Faculty of Architecture, Building and Planning, University of Melbourne, and Paul Tagell and team at Marketing and Communications, University of Melbourne - Media Insights 2011

Instructions:
(1) create a database and import unimelb_drupal_distro.sql
(2) edit /sites/default/settings.php and set the DATABASE, USERNAME, PASSWORD
(3) delete the _DEPLOY directory
(4) contact Media Insights for further support - media@insights.net.au